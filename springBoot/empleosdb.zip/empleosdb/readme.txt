Instrucciones.

- Si estas utilizando MySQL 5.7 o inferior por favor utiliza el archivo llamado "empleosdb-mysql5.sql" para crear tu base de datos.

- Si estas utilizando MySQL 8.0 o superior por favor utiliza el archivo llamado "empleosdb-mysql8.sql" para crear tu base de datos.

